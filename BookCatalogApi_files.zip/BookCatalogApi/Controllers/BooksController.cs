using AutoMapper;
using BookCatalogApi.Common;
using BookCatalogApi.DTOs;
using BookCatalogApi.Models;
using BookCatalogApi.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace BookCatalogApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BooksController : ControllerBase
{
    private readonly IBookRepository _repo;
    private readonly IMapper _mapper;

    public BooksController(IBookRepository repo, IMapper mapper)
    {
        _repo = repo;
        _mapper = mapper;
    }

    // GET api/books
    [HttpGet]
    public async Task<ActionResult<ReturnResult<List<BookDto>>>> GetAll()
    {
        var books = await _repo.GetAllAsync();
        return Ok(ReturnResult<List<BookDto>>.Ok(_mapper.Map<List<BookDto>>(books)));
    }

    // GET api/books/5
    [HttpGet("{id:int}")]
    public async Task<ActionResult<ReturnResult<BookDto>>> GetById(int id)
    {
        var book = await _repo.GetByIdAsync(id);
        if (book == null)
            return NotFound(ReturnResult<BookDto>.Fail($"Книга с Id={id} не найдена"));

        return Ok(ReturnResult<BookDto>.Ok(_mapper.Map<BookDto>(book)));
    }

    // GET api/books/search?author=Толстой
    [HttpGet("search")]
    public async Task<ActionResult<ReturnResult<List<BookDto>>>> SearchByAuthor([FromQuery] string author)
    {
        if (string.IsNullOrWhiteSpace(author))
            return BadRequest(ReturnResult<List<BookDto>>.Fail("Укажите автора"));

        var books = await _repo.GetByAuthorAsync(author);
        return Ok(ReturnResult<List<BookDto>>.Ok(
            _mapper.Map<List<BookDto>>(books), $"Найдено: {books.Count}"));
    }

    // POST api/books
    [HttpPost]
    public async Task<ActionResult<ReturnResult<BookDto>>> Create(BookSaveDto dto)
    {
        var book = _mapper.Map<Book>(dto);
        await _repo.AddAsync(book);

        var result = ReturnResult<BookDto>.Ok(_mapper.Map<BookDto>(book), "Книга добавлена");
        return CreatedAtAction(nameof(GetById), new { id = book.Id }, result);
    }

    // PUT api/books/5
    [HttpPut("{id:int}")]
    public async Task<ActionResult<ReturnResult<BookDto>>> Update(int id, BookSaveDto dto)
    {
        var book = await _repo.GetByIdAsync(id);
        if (book == null)
            return NotFound(ReturnResult<BookDto>.Fail($"Книга с Id={id} не найдена"));

        _mapper.Map(dto, book);
        await _repo.UpdateAsync(book);

        return Ok(ReturnResult<BookDto>.Ok(_mapper.Map<BookDto>(book), "Книга обновлена"));
    }

    // DELETE api/books/5
    [HttpDelete("{id:int}")]
    public async Task<ActionResult<ReturnResult<bool>>> Delete(int id)
    {
        var book = await _repo.GetByIdAsync(id);
        if (book == null)
            return NotFound(ReturnResult<bool>.Fail($"Книга с Id={id} не найдена"));

        await _repo.DeleteAsync(book);
        return Ok(ReturnResult<bool>.Ok(true, "Книга удалена"));
    }
}
