using BookCatalogApi.Data;
using BookCatalogApi.Models;
using Microsoft.EntityFrameworkCore;

namespace BookCatalogApi.Repositories;

public class BookRepository : IBookRepository
{
    private readonly AppDbContext _db;
    public BookRepository(AppDbContext db) => _db = db;

    public async Task<List<Book>> GetAllAsync() =>
        await _db.Books.AsNoTracking().ToListAsync();

    public async Task<Book?> GetByIdAsync(int id) =>
        await _db.Books.FirstOrDefaultAsync(b => b.Id == id);

    public async Task<List<Book>> GetByAuthorAsync(string author) =>
        await _db.Books.AsNoTracking()
            .Where(b => b.Author.Contains(author))
            .ToListAsync();

    public async Task<Book> AddAsync(Book book)
    {
        _db.Books.Add(book);
        await _db.SaveChangesAsync();
        return book;
    }

    public async Task UpdateAsync(Book book)
    {
        _db.Books.Update(book);
        await _db.SaveChangesAsync();
    }

    public async Task DeleteAsync(Book book)
    {
        _db.Books.Remove(book);
        await _db.SaveChangesAsync();
    }
}
