namespace BookCatalogApi.Common;

public class ReturnResult<T>
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public T? Data { get; set; }

    public static ReturnResult<T> Ok(T data, string message = "OK") =>
        new() { Success = true, Message = message, Data = data };

    public static ReturnResult<T> Fail(string message) =>
        new() { Success = false, Message = message, Data = default };
}
