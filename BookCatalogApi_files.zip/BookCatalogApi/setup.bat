@echo off
chcp 65001 >nul
echo === Удаление файлов шаблона ===
if exist WeatherForecast.cs del WeatherForecast.cs
if exist Controllers\WeatherForecastController.cs del Controllers\WeatherForecastController.cs

echo === Установка пакетов ===
dotnet add package Microsoft.EntityFrameworkCore.SqlServer --version 10.0.*
dotnet add package Microsoft.EntityFrameworkCore.Design --version 10.0.*
dotnet add package AutoMapper --version 12.0.1
dotnet add package AutoMapper.Extensions.Microsoft.DependencyInjection --version 12.0.1
dotnet add package Swashbuckle.AspNetCore

echo === Сборка ===
dotnet build
echo.
echo Если сборка успешна, выполните:
echo   dotnet ef migrations add InitialCreate
echo   dotnet ef database update
echo   dotnet run
